<?php
/**
 * CRM AI Consultant — Канал Viber
 * Version: 2.6.7 — Повноцінна версія з прямим посиланням
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

function crm_ai_send_to_viber($site_id, $session, $user_message) {
    
    $site_file = dirname(__DIR__) . '/sites/' . $site_id . '.json';
    if (!file_exists($site_file)) {
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    $settings = json_decode(file_get_contents($site_file), true);

    $viber_number = trim($settings['viber_number'] ?? '');

    // Зберігаємо повідомлення клієнта
    crm_ai_save_message($site_id, $session, $user_message, 'client');

    if (!empty($viber_number)) {
        // Створюємо пряме посилання на чат у Viber
        $clean_number = preg_replace('/[^0-9]/', '', $viber_number);
        $viber_link = "viber://chat?number=" . $clean_number;

        $reply = "✅ Я отримав ваше повідомлення!\n\n"
               . "Найшвидше я відповідаю в **Viber**.\n\n"
               . "👉 [Написати мені в Viber](" . $viber_link . ")\n\n"
               . "Мій номер: " . $viber_number;

        crm_ai_save_message($site_id, $session, $reply, 'bot');

        return ['success' => true, 'message' => $reply];
    } else {
        $reply = "Viber канал ще налаштовується.\n\n"
               . "Напишіть мені в **Telegram** — я відповім швидко.";

        crm_ai_save_message($site_id, $session, $reply, 'bot');

        return ['success' => true, 'message' => $reply];
    }
}