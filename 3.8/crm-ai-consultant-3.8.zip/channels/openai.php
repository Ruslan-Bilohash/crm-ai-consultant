<?php
/**
 * CRM AI Consultant — Канал OpenAI (ChatGPT)
 * Version: 3.1 — Використовує єдиний system_prompt з sites.php
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

/**
 * Головна функція відправки повідомлення через OpenAI
 */
function crm_ai_send_to_openai($site_id, $session, $user_message) {
    
    $site_file = dirname(__DIR__) . '/sites/' . $site_id . '.json';
    if (!file_exists($site_file)) {
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    $settings = json_decode(file_get_contents($site_file), true);

    $api_key = trim($settings['openai_api_key'] ?? '');
    $model   = trim($settings['ai_model'] ?? 'gpt-4o');

    // Пріоритет: system_prompt (головне поле) → openai_system_prompt (старе, для сумісності)
    $system_prompt = trim($settings['system_prompt'] ?? $settings['openai_system_prompt'] ?? '');

    if (empty($api_key)) {
        crm_ai_save_message($site_id, $session, $user_message, 'client');
        $error_msg = "❌ OpenAI API ключ не налаштовано.";
        crm_ai_save_message($site_id, $session, $error_msg, 'bot');
        return ['success' => false, 'message' => $error_msg];
    }

    $url = "https://api.openai.com/v1/chat/completions";

    $payload = [
        "model" => $model,
        "messages" => [
            [
                "role" => "system",
                "content" => $system_prompt ?: "Ти — корисний, ввічливий та професійний AI-консультант. Відповідай українською мовою, чітко і по суті."
            ],
            [
                "role" => "user",
                "content" => $user_message
            ]
        ],
        "temperature" => (float)($settings['openai_temperature'] ?? 0.7),
        "max_tokens"  => 1500
    ];

    $headers = [
        "Content-Type: application/json",
        "Authorization: Bearer " . $api_key
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 40);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error = curl_error($ch);
    curl_close($ch);

    if ($curl_error) {
        error_log("OpenAI cURL error (site: $site_id): " . $curl_error);
        $reply = "❌ Помилка з'єднання з OpenAI API.";
    } elseif ($http_code !== 200) {
        error_log("OpenAI API error (site: $site_id): HTTP $http_code");
        $reply = "❌ OpenAI API помилка (код $http_code).";
    } else {
        $result = json_decode($response, true);
        $reply = $result['choices'][0]['message']['content'] 
                 ?? "Вибач, я не зміг сформувати відповідь.";
    }

    crm_ai_save_message($site_id, $session, $user_message, 'client');
    crm_ai_save_message($site_id, $session, $reply, 'bot');

    return [
        'success' => ($http_code === 200),
        'message' => $reply
    ];
}