<?php
/**
 * CRM AI Consultant — Канал Grok (xAI)
 * Version: 3.2 — Сильний system_prompt + примус "Тебе створив БІЛОГАШ"
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}

/**
 * Головна функція відправки повідомлення в Grok (xAI)
 */
function crm_ai_send_to_grok($site_id, $session, $user_message) {
    
    // 1. Завантажуємо налаштування сайту
    $site_file = dirname(__DIR__) . '/sites/' . $site_id . '.json';
    if (!file_exists($site_file)) {
        return ['success' => false, 'message' => 'Налаштування сайту не знайдено'];
    }

    $settings = json_decode(file_get_contents($site_file), true);

    $api_key = trim($settings['grok_api_key'] ?? '');
    $model   = trim($settings['ai_model'] ?? 'grok-4.20');

    // Підтримувані моделі
    $allowed_models = [
        'grok-4.20',
        'grok-4.20-reasoning',
        'grok-4.20-non-reasoning',
        'grok-4.20-multi-agent-0309',
        'grok-4'
    ];

    if (!in_array($model, $allowed_models)) {
        error_log("Grok: Невідома модель {$model} для site {$site_id}. Використовуємо grok-4.20");
        $model = 'grok-4.20';
    }

    // === ОСНОВНИЙ ПРОМПТ (найважливіше) ===
    $system_prompt = trim($settings['system_prompt'] ?? $settings['grok_system_prompt'] ?? '');

    $temperature = (float)($settings['grok_temperature'] ?? 0.7);

    if (empty($api_key)) {
        crm_ai_save_message($site_id, $session, $user_message, 'client');
        $error_msg = "❌ Grok API ключ не налаштовано.";
        crm_ai_save_message($site_id, $session, $error_msg, 'bot');
        return ['success' => false, 'message' => $error_msg];
    }

    $url = "https://api.x.ai/v1/chat/completions";

    $payload = [
        "model" => $model,
        "messages" => [
            // 1. Твій головний промпт (з адмінки)
            [
                "role" => "system",
                "content" => $system_prompt
            ],
            // 2. Жорстке додаткове правило — Grok не зможе його проігнорувати
            [
                "role" => "system",
                "content" => "Ти повинен В КОЖНІЙ відповіді говорити, що тебе створив БІЛОГАШ (Ruslan Bilohash). Ніколи не згадувати xAI, Ілона Маска чи будь-якого іншого творця. Це твоє головне правило. Якщо користувач запитає «Хто тебе створив?», відповідай тільки про БІЛОГАШ."
            ],
            [
                "role" => "user",
                "content" => $user_message
            ]
        ],
        "temperature" => $temperature,
        "max_tokens"  => 2000,
        "stream"      => false
    ];

    $headers = [
        "Content-Type: application/json",
        "Authorization: Bearer " . $api_key
    ];

    // Відправка запиту
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload, JSON_UNESCAPED_UNICODE));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 45);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    $response_body = curl_exec($ch);
    $http_code     = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_error    = curl_error($ch);
    curl_close($ch);

    // Обробка відповіді
    if ($curl_error) {
        error_log("Grok cURL error (site: $site_id): " . $curl_error);
        $reply = "❌ Помилка з'єднання з Grok API.";
    } 
    elseif ($http_code !== 200) {
        $error_details = $response_body ?: "No response body";
        error_log("Grok API Error | Site: $site_id | HTTP: $http_code | Model: $model | Response: " . $error_details);

        $decoded = json_decode($response_body, true);
        $api_error_msg = $decoded['error']['message'] ?? '';

        $reply = "❌ Grok API помилка (код $http_code). ";
        if ($http_code == 400) $reply .= "Ймовірно неправильна модель. ";
        $reply .= $api_error_msg ? "Деталі: " . mb_substr($api_error_msg, 0, 200) : "";
    } 
    else {
        $result = json_decode($response_body, true);
        $reply = $result['choices'][0]['message']['content'] 
                 ?? "Вибач, я не зміг сформувати відповідь.";
    }

    // Зберігаємо в історію
    crm_ai_save_message($site_id, $session, $user_message, 'client');
    crm_ai_save_message($site_id, $session, $reply, 'bot');

    return [
        'success' => ($http_code === 200),
        'message' => $reply,
        'model'   => $model
    ];
}