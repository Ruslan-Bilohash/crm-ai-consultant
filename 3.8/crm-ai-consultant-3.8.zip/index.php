<?php
/**
 * CRM AI Consultant — Головний файл віджету
 * Version: 3.0.1 — Повна підтримка всіх налаштувань дизайну
 */

define('CRM_AI_CONSULTANT', true);

if (ob_get_level()) ob_clean();

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/functions.php';

// ====================== AJAX ======================
if (isset($_GET['action']) || isset($_POST['action'])) {
    header('Content-Type: application/json; charset=utf-8');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type');

    $action  = $_GET['action'] ?? $_POST['action'] ?? '';
    $site_id = $_GET['site_id'] ?? $_POST['site_id'] ?? '';
    $session = $_GET['session'] ?? $_POST['session'] ?? '';
    $message = $_POST['message'] ?? '';

    if ($action === 'crm_ai_send') {
        $result = crm_ai_process_message($site_id, $session, $message);
        echo json_encode($result, JSON_UNESCAPED_UNICODE);
        exit;
    }

    if ($action === 'crm_ai_get_messages') {
        $messages = crm_ai_get_conversation($site_id, $session);
        echo json_encode($messages, JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Невідома дія']);
    exit;
}

// ====================== ВІДЖЕТ ======================
$site_id = trim($_GET['site'] ?? '');

if (empty($site_id)) {
    header('Content-Type: text/plain; charset=utf-8');
    die('Використовуйте ?site=ВАШ_SITE_ID');
}

$site_file = __DIR__ . '/sites/' . $site_id . '.json';

if (!file_exists($site_file)) {
    header('Content-Type: text/plain; charset=utf-8');
    die("Налаштування для site_id '{$site_id}' не знайдено");
}

$settings = json_decode(file_get_contents($site_file), true);

if (empty($settings['enable_chat'] ?? false)) {
    header('Content-Type: text/plain; charset=utf-8');
    die("Чат вимкнено для цього сайту");
}

// Повний набір налаштувань для чату
$config = [
    'ajax_url'          => 'https://bilohash.com/ai/crm/index.php',
    'site_id'           => $site_id,
    'chat_title'        => $settings['chat_title']        ?? 'AI Consultant',
    'chat_subtitle'     => $settings['chat_subtitle']     ?? 'Швидка допомога',
    'bot_icon'          => $settings['bot_icon']          ?? '🤖',
    'position'          => $settings['position']          ?? 'right',
    'widget_color'      => $settings['widget_color']      ?? '#22d3ee',
    'chat_bg_color'     => $settings['chat_bg_color']     ?? '#0f172a',
    'header_bg_color'   => $settings['header_bg_color']   ?? '#1e2937',
    'user_bubble_color' => $settings['user_bubble_color'] ?? '#22d3ee',
    'bot_bubble_color'  => $settings['bot_bubble_color']  ?? '#334155',
    'welcome_text'      => $settings['welcome_text']      ?? 'Добрий день! Як я можу допомогти вам сьогодні?',
    'auto_open'         => !empty($settings['auto_open']),
    'auto_open_delay'   => (int)($settings['auto_open_delay'] ?? 7000),
];

header('Content-Type: application/javascript; charset=utf-8');
header('X-Content-Type-Options: nosniff');
header('Cache-Control: no-cache');

if (ob_get_level()) ob_clean();

echo "window.crmAI = " . json_encode($config, JSON_UNESCAPED_UNICODE | JSON_HEX_APOS | JSON_HEX_QUOT) . ";\n\n";
echo "var script = document.createElement('script');\n";
echo "script.src = 'https://bilohash.com/ai/crm/assets/chat.js?v=3.0.1';\n";
echo "document.head.appendChild(script);\n";

exit;