<?php
/**
 * CRM AI Consultant — Налаштування OpenAI (ChatGPT)
 * Version: 3.1 — Прибрано дублювання промпту (використовується system_prompt з sites.php)
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}
?>

<div id="settings_openai" class="channel-settings <?= ($edit_site['default_channel'] ?? '') === 'openai' ? '' : 'hidden' ?>">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fas fa-brain text-purple-400 text-2xl"></i>
        Налаштування OpenAI (ChatGPT)
    </h3>

    <div class="space-y-10">

        <!-- API Key -->
        <div>
            <label class="block text-sm text-zinc-400 mb-2">OpenAI API Key</label>
            <input type="text" name="openai_api_key"
                   value="<?= htmlspecialchars($edit_site['openai_api_key'] ?? '') ?>"
                   class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono text-sm"
                   placeholder="sk-proj-................................">
            <p class="text-xs text-zinc-500 mt-2">
                Отримати ключ: <a href="https://platform.openai.com/api-keys" target="_blank" class="text-sky-400 hover:underline">platform.openai.com/api-keys</a>
            </p>
        </div>

        <!-- Модель + Температура -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8 border-t border-zinc-700">
            <div>
                <label class="block text-sm text-zinc-400 mb-2">Модель OpenAI</label>
                <select name="ai_model" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="gpt-4o" <?= ($edit_site['ai_model'] ?? '') === 'gpt-4o' ? 'selected' : '' ?>>gpt-4o — Найкраща (рекомендовано)</option>
                    <option value="gpt-4o-mini" <?= ($edit_site['ai_model'] ?? '') === 'gpt-4o-mini' ? 'selected' : '' ?>>gpt-4o-mini — Швидка</option>
                    <option value="o1-preview" <?= ($edit_site['ai_model'] ?? '') === 'o1-preview' ? 'selected' : '' ?>>o1-preview — З сильним міркуванням</option>
                </select>
            </div>

            <div>
                <label class="block text-sm text-zinc-400 mb-2">Температура (креативність)</label>
                <select name="openai_temperature" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="0.7" <?= ($edit_site['openai_temperature'] ?? '0.7') === '0.7' ? 'selected' : '' ?>>0.7 — Збалансована (рекомендовано)</option>
                    <option value="0.3" <?= ($edit_site['openai_temperature'] ?? '0.7') === '0.3' ? 'selected' : '' ?>>0.3 — Точна</option>
                    <option value="1.0" <?= ($edit_site['openai_temperature'] ?? '0.7') === '1.0' ? 'selected' : '' ?>>1.0 — Креативна</option>
                </select>
            </div>
        </div>

    </div>
</div>