<?php
/**
 * admin/navigation.php — Світла сучасна шапка адмін-панелі
 * Version: 3.5 — Приємний світло-голубий дизайн
 */
require_once dirname(__DIR__) . '/version.php';
?>

<nav class="bg-white border-b border-zinc-200 shadow-sm sticky top-0 z-50">
    <div class="max-w-7xl mx-auto px-6 py-5">
        <div class="flex items-center justify-between">

            <!-- Логотип + назва -->
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-gradient-to-br from-sky-400 to-blue-500 rounded-2xl flex items-center justify-center text-3xl shadow-md">
                    🤖
                </div>
                <div>
                    <h1 class="text-2xl font-semibold text-zinc-900 tracking-tight">CRM AI Consultant</h1>
                    <p class="text-xs text-zinc-500 font-mono -mt-0.5">AI Chat Platform</p>
                </div>
            </div>

            <!-- Меню -->
            <div class="hidden md:flex items-center gap-8 text-sm">
                <a href="index.php" 
                   class="flex items-center gap-2 px-5 py-2 text-zinc-700 hover:text-sky-600 transition-all <?= basename($_SERVER['PHP_SELF']) === 'index.php' ? 'text-sky-600 border-b-2 border-sky-500' : '' ?>">
                    <i class="fas fa-home"></i>
                    <span>Сайти</span>
                </a>
                
                <a href="conversations.php" 
                   class="flex items-center gap-2 px-5 py-2 text-zinc-700 hover:text-sky-600 transition-all <?= basename($_SERVER['PHP_SELF']) === 'conversations.php' ? 'text-sky-600 border-b-2 border-sky-500' : '' ?>">
                    <i class="fas fa-clock"></i>
                    <span>Історія чатів</span>
                </a>
                
                <a href="../documentation.html" target="_blank"
                   class="flex items-center gap-2 px-5 py-2 text-zinc-700 hover:text-sky-600 transition-all">
                    <i class="fas fa-book"></i>
                    <span>Документація</span>
                </a>
            </div>

            <!-- Правий блок -->
            <div class="flex items-center gap-4">
                <!-- Версія -->
                <div class="hidden sm:flex items-center text-xs font-mono bg-sky-50 text-sky-600 px-4 py-2 rounded-2xl border border-sky-200">
                    v<?= CRM_AI_VERSION ?>
                </div>

                <!-- Вихід -->
                <a href="?logout=1" 
                   class="flex items-center gap-2 px-5 py-2.5 text-sm text-red-500 hover:text-red-600 hover:bg-red-50 rounded-2xl transition-all">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="hidden sm:inline">Вийти</span>
                </a>

                <!-- Мобільне меню -->
                <button onclick="toggleMobileMenu()" class="md:hidden text-2xl text-zinc-600 hover:text-zinc-900">
                    <i class="fas fa-bars" id="burger"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Мобільне меню -->
    <div id="mobileMenu" class="hidden md:hidden bg-white border-t border-zinc-200 px-6 py-4">
        <a href="index.php" class="block py-4 px-5 text-zinc-700 hover:bg-zinc-100 rounded-2xl flex items-center gap-3">
            <i class="fas fa-home"></i> Сайти
        </a>
        <a href="conversations.php" class="block py-4 px-5 text-zinc-700 hover:bg-zinc-100 rounded-2xl flex items-center gap-3">
            <i class="fas fa-clock"></i> Історія чатів
        </a>
        <a href="../documentation.html" target="_blank" class="block py-4 px-5 text-zinc-700 hover:bg-zinc-100 rounded-2xl flex items-center gap-3">
            <i class="fas fa-book"></i> Документація
        </a>
    </div>
</nav>

<script>
function toggleMobileMenu() {
    const menu = document.getElementById('mobileMenu');
    const icon = document.getElementById('burger');
    
    if (menu.classList.contains('hidden')) {
        menu.classList.remove('hidden');
        icon.classList.replace('fa-bars', 'fa-times');
    } else {
        menu.classList.add('hidden');
        icon.classList.replace('fa-times', 'fa-bars');
    }
}
</script>