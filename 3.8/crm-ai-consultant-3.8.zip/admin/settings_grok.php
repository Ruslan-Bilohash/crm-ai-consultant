<?php
if (!defined('CRM_AI_CONSULTANT')) die('Access denied');
?>

<div id="settings_grok" class="channel-settings <?= ($edit_site['default_channel'] ?? '') === 'grok' ? '' : 'hidden' ?>">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fas fa-robot text-orange-400 text-2xl"></i>
        Налаштування Grok (xAI)
    </h3>

    <div class="space-y-8">
        <div>
            <label class="block text-sm text-zinc-400 mb-2">Grok API Key</label>
            <input type="text" name="grok_api_key" value="<?= htmlspecialchars($edit_site['grok_api_key'] ?? '') ?>"
                   class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono">
        </div>

        <!-- Модель + Температура -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
                <label class="block text-sm text-zinc-400 mb-2">Модель Grok</label>
                <select name="ai_model" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="grok-4.20" <?= ($edit_site['ai_model'] ?? '') === 'grok-4.20' ? 'selected' : '' ?>>grok-4.20 — Основна</option>
                    <option value="grok-4.20-reasoning" <?= ($edit_site['ai_model'] ?? '') === 'grok-4.20-reasoning' ? 'selected' : '' ?>>grok-4.20-reasoning</option>
                    <option value="grok-4.20-non-reasoning" <?= ($edit_site['ai_model'] ?? '') === 'grok-4.20-non-reasoning' ? 'selected' : '' ?>>grok-4.20-non-reasoning</option>
                </select>
            </div>
            <div>
                <label class="block text-sm text-zinc-400 mb-2">Температура</label>
                <select name="grok_temperature" class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
                    <option value="0.7" selected>0.7 — Збалансована</option>
                    <option value="0.5">0.5 — Точна</option>
                    <option value="1.0">1.0 — Креативна</option>
                </select>
            </div>
        </div>
    </div>
</div>