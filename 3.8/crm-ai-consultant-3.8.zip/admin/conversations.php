<?php
/**
 * CRM AI Consultant — Історія розмов
 * Version: 2.7.0
 */

define('CRM_AI_CONSULTANT', true);

error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../crm-ai-error.log');

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/functions.php';

$conversations_dir = __DIR__ . '/../conversations';

$conversations = [];
$files = glob($conversations_dir . '/*.json');

foreach ($files as $file) {
    $data = json_decode(file_get_contents($file), true);
    if (is_array($data) && !empty($data)) {
        $filename = basename($file);
        $site_id = 'unknown';
        if (preg_match('/^(.+?)_/', $filename, $m)) {
            $site_id = $m[1];
        }

        $last = end($data);

        $conversations[] = [
            'file'          => $filename,
            'site_id'       => $site_id,
            'message_count' => count($data),
            'last_time'     => $last['time'] ?? filemtime($file),
            'last_message'  => $last['content'] ?? $last['text'] ?? '',
        ];
    }
};

usort($conversations, function($a, $b) {
    return strtotime($b['last_time'] ?? 0) <=> strtotime($a['last_time'] ?? 0);
});
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Історія розмов</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .conversation-row:hover { background-color: #1f2937; }
        .modal { display: none; position: fixed; inset: 0; background: rgba(0,0,0,0.85); z-index: 10000; align-items: center; justify-content: center; }
        .modal-content { background: #18181b; width: 95%; max-width: 820px; max-height: 92vh; border-radius: 20px; overflow: hidden; }
    </style>
</head>
<body class="bg-zinc-950 text-zinc-100">

<?php include 'navigation.php'; ?>

<div class="max-w-7xl mx-auto p-8">
    <h1 class="text-4xl font-bold mb-2">Історія розмов</h1>
    <p class="text-zinc-400 mb-8">Всі чати з відвідувачами сайтів</p>

    <?php if (empty($conversations)): ?>
        <div class="bg-zinc-900 rounded-3xl p-20 text-center">
            <div class="text-8xl mb-6">📭</div>
            <h3 class="text-3xl font-medium">Поки немає розмов</h3>
        </div>
    <?php else: ?>
        <div class="bg-zinc-900 rounded-3xl overflow-hidden">
            <table class="w-full">
                <thead class="bg-zinc-950">
                    <tr>
                        <th class="px-8 py-5 text-left">Сайт</th>
                        <th class="px-8 py-5 text-left">Повідомлень</th>
                        <th class="px-8 py-5 text-left">Останнє повідомлення</th>
                        <th class="px-8 py-5 text-left">Час</th>
                        <th class="w-40"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($conversations as $conv): ?>
                    <tr class="conversation-row border-t border-zinc-800 hover:bg-zinc-800" onclick="loadConversation('<?= htmlspecialchars($conv['file']) ?>')">
                        <td class="px-8 py-6 font-medium"><?= htmlspecialchars($conv['site_id']) ?></td>
                        <td class="px-8 py-6"><?= $conv['message_count'] ?></td>
                        <td class="px-8 py-6 text-sm text-zinc-300 truncate max-w-md">
                            <?= htmlspecialchars(mb_substr($conv['last_message'], 0, 95)) ?>...
                        </td>
                        <td class="px-8 py-6 text-sm text-zinc-500">
                            <?= date('d.m.Y H:i', strtotime($conv['last_time'])) ?>
                        </td>
                        <td class="px-8 py-6 text-right">
                            <button onclick="event.stopImmediatePropagation(); loadConversation('<?= htmlspecialchars($conv['file']) ?>')" 
                                    class="bg-sky-600 hover:bg-sky-500 px-6 py-3 rounded-2xl text-sm">
                                Переглянути
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<!-- Модальне вікно -->
<div id="modal" class="modal">
    <div class="modal-content">
        <div class="bg-zinc-800 px-6 py-4 flex justify-between items-center">
            <h2 class="text-xl font-semibold">Перегляд розмови</h2>
            <button onclick="closeModal()" class="text-3xl leading-none text-zinc-400 hover:text-white">×</button>
        </div>
        <div id="modal-body" class="p-6 overflow-y-auto bg-zinc-950" style="max-height: 70vh;">
            <!-- AJAX завантажить сюди повідомлення -->
        </div>
        <div class="p-4 bg-zinc-900 text-xs text-center text-zinc-500 border-t border-zinc-700">
            Файл: <span id="modal-filename" class="font-mono"></span>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
function loadConversation(filename) {
    const modal = document.getElementById('modal');
    const body = document.getElementById('modal-body');
    const filenameSpan = document.getElementById('modal-filename');

    filenameSpan.textContent = filename;
    body.innerHTML = `<div class="text-center py-12"><i class="fas fa-spinner fa-spin text-4xl text-zinc-500"></i><p class="mt-6 text-zinc-400">Завантаження розмови...</p></div>`;
    modal.style.display = 'flex';

    fetch('get-conversation.php?file=' + encodeURIComponent(filename))
        .then(r => r.text())
        .then(html => {
            body.innerHTML = html;
        })
        .catch(() => {
            body.innerHTML = `<p class="text-red-400 text-center py-10">Помилка завантаження розмови</p>`;
        });
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}
</script>

</body>
</html>