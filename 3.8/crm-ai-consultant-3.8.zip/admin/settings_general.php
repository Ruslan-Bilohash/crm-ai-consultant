<?php
/**
 * CRM AI Consultant — Загальні налаштування бота
 * Привітання, інструкції для бота, автовідкриття тощо
 */

if (!defined('CRM_AI_CONSULTANT')) {
    die('Access denied');
}
?>

<div id="settings_general" class="channel-settings">

    <h3 class="text-xl font-medium mb-6 flex items-center gap-3 border-b border-zinc-700 pb-4">
        <i class="fas fa-cog text-sky-400 text-2xl"></i>
        Загальні налаштування бота
    </h3>

    <!-- Привітання при першому відкритті -->
    <div class="mb-8">
        <label class="block text-sm text-zinc-400 mb-2">Привітання користувача (перше повідомлення)</label>
        <textarea name="welcome_text" rows="3" 
                  class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4"><?= htmlspecialchars($edit_site['welcome_text'] ?? 'Добрий день! Як я можу допомогти вам сьогодні?') ?></textarea>
        <p class="text-xs text-zinc-500 mt-1">Це повідомлення з’явиться автоматично при відкритті чату</p>
    </div>

    <!-- Інструкції для бота (System Prompt) -->
    <div class="mb-8">
        <label class="block text-sm text-zinc-400 mb-2">Інструкції для бота (System Prompt)</label>
        <textarea name="bot_system_prompt" rows="6" 
                  class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 font-mono text-sm"><?= htmlspecialchars($edit_site['bot_system_prompt'] ?? 'Ти — дружній та професійний AI-консультант. Відповідай коротко, по суті, українською мовою. Будь корисним, ввічливим і допомагай клієнту максимально швидко.') ?></textarea>
        <p class="text-xs text-zinc-500 mt-1">
            Це те, що "знає" бот про свою роль. Чим детальніше — тим краще він працюватиме.
        </p>
    </div>

    <!-- Автовідкриття чату -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
            <label class="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" name="auto_open" value="1" 
                       <?= !empty($edit_site['auto_open']) ? 'checked' : '' ?>>
                <span class="text-sm font-medium">Автоматично відкривати чат</span>
            </label>
        </div>

        <div>
            <label class="block text-sm text-zinc-400 mb-2">Через скільки секунд відкривати чат</label>
            <div class="flex items-center gap-3">
                <input type="number" name="auto_open_delay" min="1000" max="30000" step="500"
                       value="<?= (int)($edit_site['auto_open_delay'] ?? 7000) ?>" 
                       class="w-32 bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4 text-center">
                <span class="text-zinc-400">мілісекунд (1000 = 1 секунда)</span>
            </div>
            <p class="text-xs text-zinc-500 mt-1">Рекомендовано: 5000–10000 мс</p>
        </div>
    </div>

    <!-- Додаткові налаштування бота -->
    <div class="mt-10 pt-8 border-t border-zinc-700">
        <label class="block text-sm text-zinc-400 mb-2">Максимальна кількість повідомлень в історії</label>
        <input type="number" name="max_history_messages" min="10" max="200" 
               value="<?= (int)($edit_site['max_history_messages'] ?? 50) ?>" 
               class="w-full bg-zinc-800 border border-zinc-700 rounded-2xl px-6 py-4">
    </div>

</div>