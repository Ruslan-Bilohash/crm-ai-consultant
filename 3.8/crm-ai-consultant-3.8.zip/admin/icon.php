<?php
/**
 * CRM AI Consultant — Модальне вікно вибору іконки бота
 * Version: 3.2
 */
?>

<!-- Модальне вікно вибору іконок -->
<div id="iconModal" class="hidden fixed inset-0 bg-black/80 z-[9999] flex items-center justify-center">
    <div class="bg-zinc-900 rounded-3xl w-full max-w-2xl mx-4 overflow-hidden shadow-2xl">
        
        <!-- Заголовок модального вікна -->
        <div class="px-6 py-4 border-b border-zinc-700 flex items-center justify-between">
            <h3 class="text-xl font-semibold flex items-center gap-2">
                <i class="fas fa-icons text-sky-400"></i>
                Оберіть іконку бота
            </h3>
            <button onclick="closeIconModal()" class="text-3xl leading-none text-zinc-400 hover:text-white transition-colors">×</button>
        </div>

        <!-- Сітка іконок -->
        <div class="p-6 max-h-[460px] overflow-y-auto">
            <div class="grid grid-cols-6 sm:grid-cols-8 md:grid-cols-10 gap-4">
                <?php
                $icons = ['🤖','🧠','💡','⚡','🌐','📡','🦾','🚀','✨','🔬','💻','🧬','🔥','🌟','📊','🧪','🛰️','🎯','🧩','🔥','🖥️','📱','🌌','🔮','🌀','💾','🧬','📡','🤖','🧪'];
                foreach ($icons as $icon) {
                    echo "
                    <button onclick=\"selectBotIcon('{$icon}')\" 
                            class='aspect-square flex items-center justify-center text-5xl hover:bg-zinc-800 rounded-2xl transition-all hover:scale-110 active:scale-95'>
                        {$icon}
                    </button>";
                }
                ?>
            </div>
        </div>

        <!-- Нижня панель -->
        <div class="px-6 py-4 border-t border-zinc-700 text-center">
            <button onclick="closeIconModal()" 
                    class="px-8 py-3 text-sm font-medium text-zinc-400 hover:text-white transition-colors">
                Закрити
            </button>
        </div>
    </div>
</div>

<script>
// Відкрити модальне вікно
function openIconModal() {
    const modal = document.getElementById('iconModal');
    modal.classList.remove('hidden');
    modal.classList.add('flex');
}

// Закрити модальне вікно
function closeIconModal() {
    const modal = document.getElementById('iconModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

// Вибрати іконку
function selectBotIcon(icon) {
    // Оновлюємо прев'ю
    document.getElementById('selected_icon_preview').innerHTML = icon;
    
    // Записуємо в приховане поле форми
    document.getElementById('bot_icon_input').value = icon;
    
    // Закриваємо вікно
    closeIconModal();
}
</script>