// admin.js - можна розширювати
console.log('CRM AI Admin JS loaded');

function toggleSidebar() {
    // логіка вже в index.php, але можна покращити
}